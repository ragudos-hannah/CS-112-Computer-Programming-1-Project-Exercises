/*
Name: Ragudos, Hannah, T.
Date: August 15, 2022

Problem:
Write a program that displays "Hello World" on the output screen
 */

package prelim.exercises;
public class HelloWorld {
    public static void main(String[] args){

        System.out.print ("Hello World");
        System.exit (0);

    } // end of main method
}// end of class
