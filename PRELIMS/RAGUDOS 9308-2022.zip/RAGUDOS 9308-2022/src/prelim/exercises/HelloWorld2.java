/*

Name: Ragudos, Hannah, T.
Programming Date : August 17, 2022

Problem:
Write a program that display "Hello World" on the output screen.

Algorithm:
1. Print "Hello World"

 */

package prelim.exercises;
public class HelloWorld2 {
    public static void main(String[] args){
        System.out.println("Hello");
        System.out.println("World");
        System.exit(0);

    } // end of main method
} // end of class

